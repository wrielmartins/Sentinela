export interface User {
  name: string;
  role: string;
  avatar: string;
  badge?: string;
}

export interface Incident {
  id: number;
  time: string;
  category: 'Segurança' | 'Médico' | 'Infraestrutura' | 'Conduta';
  description: string;
  location: string;
  severity: 'Crítico' | 'Urgente' | 'Normal';
  officer: string;
  officerAvatar: string;
}

export interface SwapRequest {
  id: number;
  date: string;
  requester: string;
  requesterAvatar: string;
  substitute: string;
  substituteAvatar: string;
  status: 'Aprovado' | 'Pendente' | 'Negado';
  time: string;
}

export interface Post {
  id: string;
  name: string;
  location: string;
  officer: string;
  officerAvatar: string;
  weapon: string;
  status: 'Ativo' | 'Em Pausa' | 'Em Trânsito';
  icon: string;
}
