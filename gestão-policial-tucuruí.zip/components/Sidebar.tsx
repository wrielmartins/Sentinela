import React from 'react';
import { useLocation, Link } from 'react-router-dom';

interface SidebarProps {
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onLogout }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const menuItems = [
    { path: '/', icon: 'dashboard', label: 'Visão Geral' },
    { path: '/day-shift', icon: 'calendar_month', label: 'Escala Diurna' },
    { path: '/night-shift', icon: 'bedtime', label: 'Escala Noturna' },
    { path: '/swaps', icon: 'swap_horiz', label: 'Permutas' },
    { path: '/reports', icon: 'warning', label: 'Ocorrências', badge: 2 },
    { path: '/profile', icon: 'person', label: 'Perfil e Avisos' },
  ];

  return (
    <aside className="w-64 bg-[#111318] flex flex-col border-r border-slate-800 flex-shrink-0 z-20 h-screen">
      <div className="p-5 flex items-center gap-3 border-b border-slate-800/50">
        <div className="bg-center bg-no-repeat bg-cover rounded-lg h-10 w-10 shadow-lg shadow-blue-900/20 bg-slate-700 flex items-center justify-center text-white">
           <span className="material-symbols-outlined">security</span>
        </div>
        <div className="flex flex-col">
          <h1 className="text-white text-base font-bold leading-tight tracking-tight">Gestão Policial</h1>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">Tucuruí - PA</p>
        </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all group ${
              isActive(item.path)
                ? 'bg-primary text-white shadow-md shadow-primary/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <span className={`material-symbols-outlined text-[22px] ${!isActive(item.path) && 'group-hover:text-primary transition-colors'}`}>
              {item.icon}
            </span>
            <div className="flex flex-1 justify-between items-center">
              <span className="text-sm font-medium">{item.label}</span>
              {item.badge && (
                <span className="bg-red-500/20 text-red-500 text-[10px] font-bold px-1.5 py-0.5 rounded border border-red-500/20">
                  {item.badge}
                </span>
              )}
            </div>
          </Link>
        ))}
        
        <div className="my-2 border-t border-slate-800 mx-2"></div>
        
        <Link
          to="/request-swap"
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors group ${
             isActive('/request-swap') ? 'bg-white/5 text-white' : ''
          }`}
        >
          <span className="material-symbols-outlined text-[22px] group-hover:text-primary transition-colors">edit_calendar</span>
          <span className="text-sm font-medium">Solicitar Permuta</span>
        </Link>
      </nav>

      <div className="p-4 border-t border-slate-800">
        <Link to="/reports" className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg h-10 bg-[#282e39] hover:bg-[#343b49] text-white text-sm font-bold transition-colors border border-slate-700">
          <span className="material-symbols-outlined text-[18px]">add</span>
          <span>Novo Plantão</span>
        </Link>
        <div className="mt-4 flex items-center gap-3 px-1">
          <img src="https://picsum.photos/32/32?random=1" alt="Avatar" className="rounded-full h-8 w-8 ring-2 ring-slate-700" />
          <div className="flex flex-col overflow-hidden">
            <p className="text-white text-xs font-semibold truncate">Coord. Roberto</p>
            <p className="text-slate-500 text-[10px] truncate">Admin</p>
          </div>
          <button onClick={onLogout} className="ml-auto text-slate-500 hover:text-white" title="Sair do sistema">
            <span className="material-symbols-outlined text-[18px]">logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
