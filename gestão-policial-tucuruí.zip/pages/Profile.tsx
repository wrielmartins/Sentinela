import React from 'react';

const Profile: React.FC = () => {
  return (
    <div className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-y-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <aside className="lg:col-span-4 space-y-6">
          <div className="bg-white dark:bg-surface-dark rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden sticky top-24">
            <div className="h-32 bg-gradient-to-r from-blue-900 to-primary relative">
              <div className="absolute inset-0 bg-black/20"></div>
            </div>
            <div className="px-6 relative flex flex-col items-center -mt-16 pb-6 border-b border-slate-100 dark:border-slate-700/50">
              <div className="rounded-full h-32 w-32 border-4 border-white dark:border-surface-dark shadow-md mb-4 bg-cover bg-center" style={{backgroundImage: 'url(https://picsum.photos/128/128?random=12)'}}></div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white text-center">CB. SILVA</h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 mt-2 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20">
                <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                Ativo
              </span>
              <div className="flex items-center gap-2 mt-4 text-slate-500 dark:text-slate-400">
                <span className="material-symbols-outlined text-lg">badge</span>
                <span className="text-sm font-medium">Matrícula: 849201</span>
              </div>
            </div>
            
            <div className="p-6 space-y-5">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
                  <span className="material-symbols-outlined text-lg">person</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">Gênero / Idade</p>
                  <p className="text-sm font-medium text-slate-900 dark:text-white mt-0.5">Masculino, 42 Anos</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                 <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
                  <span className="material-symbols-outlined text-lg">phone_iphone</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">Telefone</p>
                  <p className="text-sm font-medium text-slate-900 dark:text-white mt-0.5">(94) 99123-4567</p>
                </div>
              </div>
               <div className="flex items-start gap-4">
                 <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
                  <span className="material-symbols-outlined text-lg">mail</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">Email Institucional</p>
                  <p className="text-sm font-medium text-slate-900 dark:text-white mt-0.5 truncate w-full">silva.pp@tucurui.pa.gov.br</p>
                </div>
              </div>
            </div>
            <div className="px-6 pb-6 pt-2">
               <button className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-medium py-2.5 px-4 rounded-lg transition-colors shadow-lg shadow-primary/20">
                <span className="material-symbols-outlined text-lg">edit</span>
                <span>Editar Perfil</span>
              </button>
            </div>
          </div>
        </aside>

        <section className="lg:col-span-8 flex flex-col h-full">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <span className="material-symbols-outlined text-primary text-3xl">campaign</span>
              Quadro de Avisos
            </h2>
            <div className="flex items-center p-1 bg-white dark:bg-surface-dark rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm overflow-x-auto">
              <button className="px-4 py-1.5 text-sm font-medium rounded-md bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm">Todos</button>
              <button className="px-4 py-1.5 text-sm font-medium rounded-md text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors whitespace-nowrap">Alta Prioridade</button>
            </div>
          </div>

          <div className="space-y-4 flex-grow">
            <article className="group relative bg-white dark:bg-surface-dark rounded-xl p-5 sm:p-6 border-l-4 border-red-500 shadow-sm hover:shadow-md transition-all duration-200 border-y border-r border-slate-200 dark:border-y-slate-800 dark:border-r-slate-800">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-400 uppercase tracking-wider">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-600 dark:bg-red-400 animate-pulse"></span>
                      Alta Prioridade
                    </span>
                    <span className="text-xs text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">schedule</span>
                      Há 2 horas
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-primary transition-colors cursor-pointer">Mudança na Escala de Plantão - Carnaval</h3>
                   <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
                    Atenção a todos os oficiais. Devido ao feriado de Carnaval, haverá reforço obrigatório nos postos de controle A e B. A nova escala provisória já está disponível no sistema de RH.
                  </p>
                </div>
              </div>
            </article>

            <article className="group bg-white dark:bg-surface-dark rounded-xl p-5 sm:p-6 border-l-4 border-amber-500 shadow-sm hover:shadow-md transition-all duration-200 border-y border-r border-slate-200 dark:border-y-slate-800 dark:border-r-slate-800">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                 <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                      Média Prioridade
                    </span>
                    <span className="text-xs text-slate-400 dark:text-slate-500 font-medium flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">calendar_today</span>
                      Ontem, 14:30
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-primary transition-colors cursor-pointer">Manutenção das Viaturas - Lote 03</h3>
                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
                    As viaturas prefixo 201, 204 e 209 passarão por manutenção preventiva nos dias 18 e 19 deste mês.
                  </p>
                </div>
              </div>
            </article>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Profile;
