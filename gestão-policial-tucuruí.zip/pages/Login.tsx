import React, { useState } from 'react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [matricula, setMatricula] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Em um cenário real, aqui haveria a validação com o backend.
    // Para esta demonstração, apenas verificamos se os campos não estão vazios.
    if (matricula && password) {
      onLogin();
    }
  };

  return (
    <div className="relative flex min-h-screen w-full items-center justify-center p-4 bg-background-dark font-display text-white overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-background-dark/90 z-10"></div>
        <div 
          className="h-full w-full bg-cover bg-center" 
          style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDzdQABpADMhN1q_2lL_0LUSOsq3mdALLCMcKm4IXyfjyvR2bkK0aQqf5sh96lHkX_sUGrGbGkM49znEHw0ZPJyuQrZ-EoOPq6YeP13Z7t2rzrMLtzP15HX0rIuoq6sbuMrlFLkuy33znTF3kXb7pgDI9FNJfzwKm3SSu0qMu13Ltd3Hz32a2kLS2tBvd4FMOFC4WAf7ClMBTDV5XcXOKRWBtvGf8NPD5JhqWgm24Gfxlvgo-Xh6Bc1nfIlOW99obgO6c0fIpF2eOs')" }}
        >
        </div>
      </div>

      {/* Login Card */}
      <div className="relative z-20 w-full max-w-[480px] flex flex-col gap-6 rounded-2xl bg-[#13161c] border border-border-dark shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)] p-6 sm:p-10 animate-[fadeIn_0.5s_ease-out]">
        {/* Header Section */}
        <div className="flex flex-col items-center gap-4 pb-2">
          {/* Logo / Emblem Placeholder */}
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 border border-primary/20 text-primary mb-2">
            <span className="material-symbols-outlined text-5xl">local_police</span>
          </div>
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">Gestão Policial</h1>
            <p className="text-text-secondary mt-1 text-base font-medium">Tucuruí - Portal do Agente</p>
          </div>
        </div>

        {/* Form Section */}
        <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
          {/* Matrícula Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium leading-none text-white" htmlFor="matricula">Matrícula</label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary flex items-center pointer-events-none">
                <span className="material-symbols-outlined text-[20px]">badge</span>
              </div>
              <input 
                className="flex w-full rounded-lg border border-border-dark bg-input-dark h-12 py-2 pl-10 pr-3 text-sm placeholder:text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all text-white" 
                id="matricula" 
                placeholder="Digite sua matrícula funcional" 
                type="text"
                value={matricula}
                onChange={(e) => setMatricula(e.target.value)}
                required
              />
            </div>
          </div>

          {/* Senha Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium leading-none text-white" htmlFor="senha">Senha</label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary flex items-center pointer-events-none">
                <span className="material-symbols-outlined text-[20px]">lock</span>
              </div>
              <input 
                className="flex w-full rounded-lg border border-border-dark bg-input-dark h-12 py-2 pl-10 pr-10 text-sm placeholder:text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all text-white" 
                id="senha" 
                placeholder="Digite sua senha" 
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button 
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-secondary hover:text-white flex items-center focus:outline-none" 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
              >
                <span className="material-symbols-outlined text-[20px]">
                  {showPassword ? 'visibility_off' : 'visibility'}
                </span>
              </button>
            </div>
          </div>

          {/* Controls Row */}
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer group">
              <div className="relative flex items-center">
                <input className="peer h-4 w-4 cursor-pointer appearance-none rounded border border-border-dark bg-input-dark checked:border-primary checked:bg-primary hover:border-primary/50 focus:ring-0 focus:ring-offset-0 transition-all" type="checkbox"/>
                <span className="material-symbols-outlined absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[12px] text-white opacity-0 peer-checked:opacity-100 pointer-events-none font-bold">check</span>
              </div>
              <span className="text-sm text-text-secondary group-hover:text-white transition-colors">Lembrar-me</span>
            </label>
            <a className="text-sm font-medium text-primary hover:text-primary-hover hover:underline transition-colors" href="#">
              Esqueceu a senha?
            </a>
          </div>

          {/* Action Button */}
          <button 
            className="mt-2 flex w-full items-center justify-center rounded-lg bg-primary py-3 px-4 text-sm font-bold text-white shadow-lg shadow-primary/25 hover:bg-primary-hover hover:shadow-primary/40 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-[#13161c] transition-all" 
            type="submit"
          >
            Entrar no Sistema
          </button>
        </form>

        {/* Footer */}
        <div className="flex flex-col gap-4 border-t border-border-dark pt-6 text-center">
          <p className="text-sm text-text-secondary">
            Ainda não tem conta? 
            <a className="font-medium text-primary hover:text-primary-hover hover:underline ml-1" href="#">
              Primeiro acesso?
            </a>
          </p>
          <div className="flex items-center justify-center gap-2 text-xs text-text-secondary opacity-60">
            <span className="material-symbols-outlined text-[14px]">security</span>
            <span>Ambiente Seguro © 2023 Polícia Penal</span>
          </div>
        </div>
      </div>

      {/* Decorative Elements for Atmosphere */}
      <div className="pointer-events-none fixed bottom-0 left-0 h-1/2 w-1/2 bg-gradient-to-tr from-primary/10 to-transparent blur-[120px]"></div>
      <div className="pointer-events-none fixed top-0 right-0 h-1/2 w-1/2 bg-gradient-to-bl from-primary/5 to-transparent blur-[120px]"></div>
    </div>
  );
};

export default Login;
