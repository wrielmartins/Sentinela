import React from 'react';

const Reports: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col h-full min-w-0 bg-background-light dark:bg-background-dark overflow-y-auto p-6 md:p-10">
      <div className="max-w-7xl mx-auto flex flex-col gap-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-col gap-1">
            <h1 className="text-slate-900 dark:text-white text-3xl md:text-4xl font-black leading-tight tracking-tight">Diário de Ocorrências</h1>
            <p className="text-slate-500 dark:text-text-secondary text-base">Registro e acompanhamento de eventos do turno</p>
          </div>
          <button className="flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold text-sm shadow-lg shadow-primary/20 transition-all active:scale-95">
            <span className="material-symbols-outlined text-[20px]">add</span>
            <span>Nova Ocorrência</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-surface-dark rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between h-32 relative overflow-hidden group">
            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <span className="material-symbols-outlined text-[64px] text-slate-900 dark:text-white">today</span>
            </div>
            <p className="text-slate-500 dark:text-text-secondary text-sm font-medium uppercase tracking-wider">Total Hoje</p>
            <div className="flex items-end gap-3">
              <span className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">14</span>
              <span className="text-green-500 text-sm font-bold mb-1.5 flex items-center">
                <span className="material-symbols-outlined text-[16px]">trending_up</span>
                +2%
              </span>
            </div>
          </div>
          <div className="bg-white dark:bg-surface-dark rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between h-32 relative overflow-hidden group">
             <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <span className="material-symbols-outlined text-[64px] text-orange-400">pending_actions</span>
            </div>
            <p className="text-slate-500 dark:text-text-secondary text-sm font-medium uppercase tracking-wider">Casos Abertos</p>
            <div className="flex items-end gap-3">
              <span className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">5</span>
              <span className="text-slate-500 dark:text-text-secondary text-sm font-bold mb-1.5">0% desde ontem</span>
            </div>
          </div>
          <div className="bg-white dark:bg-surface-dark rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between h-32 relative overflow-hidden group">
             <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <span className="material-symbols-outlined text-[64px] text-red-500">warning</span>
            </div>
            <p className="text-slate-500 dark:text-text-secondary text-sm font-medium uppercase tracking-wider">Alertas Críticos</p>
            <div className="flex items-end gap-3">
              <span className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">2</span>
              <span className="text-red-500 text-sm font-bold mb-1.5 flex items-center">
                <span className="material-symbols-outlined text-[16px]">trending_up</span>
                +10%
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-surface-dark rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
           <div className="overflow-x-auto">
             <table className="w-full text-left border-collapse">
               <thead>
                 <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-surface-dark/50">
                   <th className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary w-32">Hora</th>
                   <th className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary w-40">Categoria</th>
                   <th className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary">Descrição</th>
                   <th className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary w-32">Gravidade</th>
                   <th className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary w-48">Oficial</th>
                   <th className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary w-20 text-right">Ações</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                 <tr className="group hover:bg-slate-50 dark:hover:bg-surface-dark/50 transition-colors">
                   <td className="py-4 px-6 font-medium text-slate-900 dark:text-white tabular-nums">14:32</td>
                   <td className="py-4 px-6">
                     <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-500/10 text-purple-600 dark:text-purple-300 border border-purple-500/20">
                       <span className="size-1.5 rounded-full bg-purple-400"></span>
                       Segurança
                     </span>
                   </td>
                   <td className="py-4 px-6">
                     <p className="text-slate-900 dark:text-white font-medium">Tentativa de comunicação externa não autorizada</p>
                     <p className="text-slate-500 dark:text-text-secondary text-xs mt-0.5">Bloco C - Ala Norte</p>
                   </td>
                   <td className="py-4 px-6">
                     <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20 uppercase tracking-wide">
                       Crítico
                     </span>
                   </td>
                   <td className="py-4 px-6">
                     <div className="flex items-center gap-2">
                       <img src="https://picsum.photos/24/24?random=10" className="size-6 rounded-full" alt="Officer"/>
                       <span className="text-slate-900 dark:text-white">Of. Mendes</span>
                     </div>
                   </td>
                   <td className="py-4 px-6 text-right">
                     <button className="text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700">
                       <span className="material-symbols-outlined">more_vert</span>
                     </button>
                   </td>
                 </tr>
                  {/* Additional rows */}
                  <tr className="group hover:bg-slate-50 dark:hover:bg-surface-dark/50 transition-colors">
                   <td className="py-4 px-6 font-medium text-slate-900 dark:text-white tabular-nums">13:15</td>
                   <td className="py-4 px-6">
                     <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-500/10 text-blue-600 dark:text-blue-300 border border-blue-500/20">
                       <span className="size-1.5 rounded-full bg-blue-400"></span>
                       Médico
                     </span>
                   </td>
                   <td className="py-4 px-6">
                     <p className="text-slate-900 dark:text-white font-medium">Solicitação de atendimento preso 104 - Febre alta</p>
                     <p className="text-slate-500 dark:text-text-secondary text-xs mt-0.5">Enfermaria solicitada</p>
                   </td>
                   <td className="py-4 px-6">
                     <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20 uppercase tracking-wide">
                       Urgente
                     </span>
                   </td>
                   <td className="py-4 px-6">
                     <div className="flex items-center gap-2">
                       <img src="https://picsum.photos/24/24?random=11" className="size-6 rounded-full" alt="Officer"/>
                       <span className="text-slate-900 dark:text-white">Of. R. Silva</span>
                     </div>
                   </td>
                   <td className="py-4 px-6 text-right">
                     <button className="text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700">
                       <span className="material-symbols-outlined">more_vert</span>
                     </button>
                   </td>
                 </tr>
               </tbody>
             </table>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
