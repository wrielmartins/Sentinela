import React from 'react';

const DayShift: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      <div className="mx-auto flex w-full max-w-[1400px] flex-1 flex-col px-4 py-8 lg:px-8 overflow-y-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1 rounded-full bg-green-500/10 px-2 py-1 text-xs font-bold text-green-500 ring-1 ring-inset ring-green-500/20">
                <span className="relative flex h-2 w-2 mr-1">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                EM ANDAMENTO
              </span>
            </div>
            <h1 className="text-3xl md:text-4xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">Escala Diurna</h1>
            <p className="text-slate-500 dark:text-text-secondary text-base md:text-lg">Gestão Operacional de Plantão - Complexo Penitenciário</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button className="flex min-w-[120px] cursor-pointer items-center justify-center gap-2 rounded-lg h-10 px-4 border border-slate-300 dark:border-slate-700 bg-transparent text-slate-700 dark:text-white text-sm font-bold hover:bg-slate-100 dark:hover:bg-surface-dark transition-all">
              <span className="material-symbols-outlined text-[20px]">print</span>
              <span>Imprimir</span>
            </button>
            <button className="flex min-w-[120px] cursor-pointer items-center justify-center gap-2 rounded-lg h-10 px-4 bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 text-sm font-bold border border-red-500/20 transition-all">
              <span className="material-symbols-outlined text-[20px]">lock</span>
              <span>Bloquear</span>
            </button>
            <button className="flex min-w-[160px] cursor-pointer items-center justify-center gap-2 rounded-lg h-10 px-4 bg-primary hover:bg-primary-dark shadow-lg shadow-primary/30 text-white text-sm font-bold transition-all">
              <span className="material-symbols-outlined text-[20px]">edit_square</span>
              <span>Modificar Escala</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <div className="flex flex-col gap-1 rounded-xl p-5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">calendar_today</span>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wide">Data Atual</p>
            </div>
            <p className="text-slate-900 dark:text-white text-2xl font-bold">04 Out 2023</p>
            <p className="text-slate-400 text-sm">Quarta-feira</p>
          </div>
          <div className="flex flex-col gap-1 rounded-xl p-5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark shadow-sm relative overflow-hidden group">
            <div className="absolute right-0 top-0 h-full w-1 bg-primary"></div>
            <div className="flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">groups</span>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wide">Plantão Ativo</p>
            </div>
            <p className="text-slate-900 dark:text-white text-2xl font-bold">Equipe Charlie</p>
            <p className="text-primary text-sm font-medium">Turno A</p>
          </div>
          <div className="flex flex-col gap-1 rounded-xl p-5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark shadow-sm">
             <div className="flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">shield_person</span>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wide">Responsável</p>
            </div>
            <p className="text-slate-900 dark:text-white text-2xl font-bold">Insp. Silva</p>
            <p className="text-slate-400 text-sm">Matrícula: 8492-B</p>
          </div>
          <div className="flex flex-col gap-1 rounded-xl p-5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">badge</span>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wide">Efetivo Total</p>
            </div>
            <p className="text-slate-900 dark:text-white text-2xl font-bold">42 Agentes</p>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 mt-2">
              <div className="bg-green-500 h-1.5 rounded-full" style={{width: '95%'}}></div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4 mb-10">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="h-6 w-1 rounded-full bg-primary block"></span>
              Unidade Principal
            </h3>
            <span className="text-sm font-medium text-slate-500 dark:text-slate-400">28 Agentes alocados</span>
          </div>
          <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px]">
                <thead>
                  <tr className="bg-slate-50 dark:bg-[#15181e] border-b border-slate-200 dark:border-slate-700">
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 w-[25%]">Posto de Serviço</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 w-[25%]">Armamento / Equipamento</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 w-[30%]">Agente Responsável</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 w-[10%]">Status</th>
                    <th className="px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 w-[10%]">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex size-8 shrink-0 items-center justify-center rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          <span className="material-symbols-outlined text-lg">cell_tower</span>
                        </div>
                        <span className="font-bold text-slate-900 dark:text-white">Guarita G1</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 rounded bg-red-500/10 px-2.5 py-1 text-xs font-bold text-red-600 dark:text-red-400 border border-red-500/20">
                        <span className="material-symbols-outlined text-[14px]">my_location</span>
                        Fuzil 5.56
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img src="https://picsum.photos/32/32?random=6" alt="Avatar" className="rounded-full size-8 bg-slate-200" />
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">Agente R. Santos</p>
                          <p className="text-xs text-slate-500">Mat. 9210</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1 rounded-full bg-green-500/10 px-2 py-1 text-xs font-medium text-green-600 dark:text-green-400">
                        <span className="h-1.5 w-1.5 rounded-full bg-green-500"></span>
                        Ativo
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-slate-400 hover:text-primary transition-colors">
                        <span className="material-symbols-outlined">edit</span>
                      </button>
                    </td>
                  </tr>
                  {/* Row 2 */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex size-8 shrink-0 items-center justify-center rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          <span className="material-symbols-outlined text-lg">door_front</span>
                        </div>
                        <span className="font-bold text-slate-900 dark:text-white">Portaria Principal</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                       <span className="inline-flex items-center gap-1.5 rounded bg-blue-500/10 px-2.5 py-1 text-xs font-bold text-blue-600 dark:text-blue-400 border border-blue-500/20">
                        <span className="material-symbols-outlined text-[14px]">token</span>
                        Pistola .40
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img src="https://picsum.photos/32/32?random=7" alt="Avatar" className="rounded-full size-8 bg-slate-200" />
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">Agente M. Souza</p>
                          <p className="text-xs text-slate-500">Mat. 8832</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                       <span className="inline-flex items-center gap-1 rounded-full bg-green-500/10 px-2 py-1 text-xs font-medium text-green-600 dark:text-green-400">
                        <span className="h-1.5 w-1.5 rounded-full bg-green-500"></span>
                        Ativo
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                       <button className="text-slate-400 hover:text-primary transition-colors">
                        <span className="material-symbols-outlined">edit</span>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DayShift;
