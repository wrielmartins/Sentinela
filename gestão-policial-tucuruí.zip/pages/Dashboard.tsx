import React from 'react';
import { Post } from '../types';

const Dashboard: React.FC = () => {
  const posts: Post[] = [
    {
      id: 'g1',
      name: 'Guarita G1 (Principal)',
      location: 'Setor Externo Norte',
      officer: 'Agt. M. Silva',
      officerAvatar: 'https://picsum.photos/32/32?random=2',
      weapon: 'Fuzil 5.56mm',
      status: 'Ativo',
      icon: 'fort'
    },
    {
      id: 'portaria',
      name: 'Portaria / Acesso',
      location: 'Controle de Entrada',
      officer: 'Agt. R. Oliveira',
      officerAvatar: 'https://picsum.photos/32/32?random=3',
      weapon: 'Triagem',
      status: 'Ativo',
      icon: 'door_front'
    },
    {
      id: 'blocoA',
      name: 'Bloco A - Carceragem',
      location: 'Ala de Segurança Máxima',
      officer: 'Agt. T. Ferreira',
      officerAvatar: 'https://picsum.photos/32/32?random=4',
      weapon: 'Chefe de Ala',
      status: 'Ativo',
      icon: 'lock'
    },
    {
      id: 'cftv',
      name: 'Monitoramento CFTV',
      location: 'Central de Vídeo',
      officer: 'Agt. A. Costa',
      officerAvatar: 'https://picsum.photos/32/32?random=5',
      weapon: 'Operador 01',
      status: 'Ativo',
      icon: 'visibility'
    }
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden relative h-full">
      <header className="flex-shrink-0 bg-[#111318]/95 backdrop-blur-sm border-b border-slate-800 z-10 sticky top-0">
        <div className="px-6 py-4 flex flex-wrap justify-between items-center gap-4">
          <div className="flex flex-col">
            <h2 className="text-white text-2xl font-bold leading-tight tracking-tight">Painel de Comando</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              <p className="text-slate-400 text-sm font-normal">Sistema Operacional • Atualizado às 08:42</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden md:flex flex-col items-end mr-2">
              <p className="text-white text-sm font-bold">14 de Novembro, 2023</p>
              <p className="text-slate-400 text-xs">Terça-feira</p>
            </div>
            <button className="flex items-center justify-center rounded-lg h-10 px-4 bg-primary hover:bg-blue-600 text-white text-sm font-bold shadow-lg shadow-blue-900/20 transition-all">
              <span className="material-symbols-outlined text-[18px] mr-2">description</span>
              Gerar Relatório Diário
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-6 scroll-smooth">
        <div className="max-w-[1600px] mx-auto flex flex-col gap-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* KPI 1 */}
            <div className="rounded-xl p-5 bg-[#1A202C] border border-slate-800 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <span className="material-symbols-outlined text-[64px] text-primary">shield_person</span>
              </div>
              <div className="flex flex-col gap-1 relative z-10">
                <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider">Equipe no Plantão</p>
                <div className="flex items-center gap-2">
                  <h3 className="text-white text-2xl font-bold">Equipe Bravo</h3>
                  <span className="bg-primary/20 text-primary text-[10px] font-bold px-2 py-0.5 rounded border border-primary/20">ATIVO</span>
                </div>
                <p className="text-slate-500 text-sm mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px]">schedule</span>
                  Início 08:00 - Término 08:00 (24h)
                </p>
              </div>
            </div>
            {/* KPI 2 */}
            <div className="rounded-xl p-5 bg-[#1A202C] border border-slate-800 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <span className="material-symbols-outlined text-[64px] text-white">groups</span>
              </div>
              <div className="flex flex-col gap-1 relative z-10">
                <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider">Efetivo Presente</p>
                <h3 className="text-white text-2xl font-bold">42 Agentes</h3>
                <div className="w-full bg-slate-700 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-green-500 h-full rounded-full" style={{width: '92%'}}></div>
                </div>
                <p className="text-slate-500 text-sm mt-1 flex justify-between">
                  <span>38 Postos Cobertos</span>
                  <span className="text-green-500 font-medium">92% Cap.</span>
                </p>
              </div>
            </div>
            {/* KPI 3 */}
            <div className="rounded-xl p-5 bg-[#1A202C] border border-slate-800 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <span className="material-symbols-outlined text-[64px] text-yellow-500">warning</span>
              </div>
              <div className="flex flex-col gap-1 relative z-10">
                <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider">Status da Unidade</p>
                <h3 className="text-white text-2xl font-bold">Atenção Normal</h3>
                <p className="text-slate-500 text-sm mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px] text-green-500">check_circle</span>
                  Sem ocorrências críticas em aberto
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="text-white text-lg font-bold flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">share_location</span>
                  Distribuição de Postos Ativos
                </h3>
                <div className="flex gap-2">
                  <button className="text-slate-400 hover:text-white px-3 py-1 text-sm bg-[#1A202C] rounded border border-slate-700">Todos</button>
                  <button className="text-white px-3 py-1 text-sm bg-primary rounded shadow-sm">Externo</button>
                  <button className="text-slate-400 hover:text-white px-3 py-1 text-sm bg-[#1A202C] rounded border border-slate-700">Interno</button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {posts.map(post => (
                  <div key={post.id} className="bg-[#1A202C] rounded-xl p-4 border border-slate-800 hover:border-slate-600 transition-colors">
                    <div className="flex justify-between items-start mb-4 border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-3">
                        <div className="bg-slate-700 p-2 rounded-lg text-white">
                          <span className="material-symbols-outlined">{post.icon}</span>
                        </div>
                        <div>
                          <h4 className="text-white font-bold text-sm">{post.name}</h4>
                          <p className="text-slate-400 text-xs">{post.location}</p>
                        </div>
                      </div>
                      <span className="flex h-3 w-3 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                      </span>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 bg-[#111318] p-2 rounded-lg border border-slate-800/50">
                        <img src={post.officerAvatar} alt={post.officer} className="rounded-full h-8 w-8 ring-1 ring-slate-600" />
                        <div className="flex flex-col">
                          <p className="text-white text-sm font-medium">{post.officer}</p>
                          <p className="text-slate-500 text-[10px]">{post.weapon}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-4">
               <div className="flex items-center justify-between">
                <h3 className="text-white text-lg font-bold flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">calendar_month</span>
                  Escala de Serviço
                </h3>
                <button className="text-primary hover:text-blue-400 text-xs font-bold">VER COMPLETO</button>
              </div>
              <div className="bg-[#1A202C] rounded-xl p-4 border border-slate-800 h-full flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <button className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-700 transition-colors">
                    <span className="material-symbols-outlined text-[18px]">chevron_left</span>
                  </button>
                  <p className="text-white text-base font-bold">Novembro 2023</p>
                  <button className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-700 transition-colors">
                     <span className="material-symbols-outlined text-[18px]">chevron_right</span>
                  </button>
                </div>
                <div className="grid grid-cols-7 mb-2">
                  {['D','S','T','Q','Q','S','S'].map((day, i) => (
                    <span key={i} className="text-slate-500 text-[10px] text-center font-bold">{day}</span>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-y-2 gap-x-1 flex-1 content-start">
                   {Array.from({length: 31}, (_, i) => i + 1).map(day => (
                      <div key={day} className="relative flex flex-col items-center">
                        <button className={`text-sm py-1 rounded w-8 h-8 flex items-center justify-center ${day === 14 ? 'bg-primary text-white font-bold shadow-lg shadow-blue-500/30' : 'text-slate-400 hover:bg-slate-700'}`}>
                          {day}
                        </button>
                        {day === 14 && <span className="absolute -bottom-1 w-1 h-1 bg-green-400 rounded-full"></span>}
                      </div>
                   ))}
                </div>
                <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col gap-2">
                  <p className="text-slate-400 text-xs font-semibold mb-1">PRÓXIMOS PLANTÕES</p>
                  <div className="flex items-center justify-between p-2 bg-[#111318] rounded border border-slate-800/50">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-8 bg-yellow-500 rounded-sm"></div>
                      <div className="flex flex-col">
                        <span className="text-white text-xs font-bold">15 Nov (Qua)</span>
                        <span className="text-slate-500 text-[10px]">Equipe Charlie</span>
                      </div>
                    </div>
                    <span className="text-slate-400 text-[10px]">08:00</span>
                  </div>
                   <div className="flex items-center justify-between p-2 bg-[#111318] rounded border border-slate-800/50">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-8 bg-purple-500 rounded-sm"></div>
                      <div className="flex flex-col">
                        <span className="text-white text-xs font-bold">16 Nov (Qui)</span>
                        <span className="text-slate-500 text-[10px]">Equipe Delta</span>
                      </div>
                    </div>
                    <span className="text-slate-400 text-[10px]">08:00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
