import React from 'react';

const SwapList: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col p-4 md:p-8 gap-8 overflow-y-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl md:text-4xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">Controle de Permutas</h1>
          <p className="text-slate-500 dark:text-text-secondary text-base font-normal">Gerenciamento de trocas de plantão e histórico operacional</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="flex flex-col gap-1 rounded-xl p-5 bg-white dark:bg-surface-dark border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="text-slate-500 dark:text-text-secondary text-sm font-medium">Aprovadas Hoje</p>
            <span className="material-symbols-outlined text-emerald-500 bg-emerald-500/10 p-1 rounded-md">check_circle</span>
          </div>
          <p className="text-slate-900 dark:text-white text-3xl font-bold mt-2">3</p>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1 mt-1">
            <span className="material-symbols-outlined text-[12px]">trending_up</span>
            +12% vs ontem
          </p>
        </div>
        <div className="flex flex-col gap-1 rounded-xl p-5 bg-white dark:bg-surface-dark border border-slate-200 dark:border-slate-800 shadow-sm">
           <div className="flex items-center justify-between">
            <p className="text-slate-500 dark:text-text-secondary text-sm font-medium">Pendentes</p>
            <span className="material-symbols-outlined text-amber-500 bg-amber-500/10 p-1 rounded-md">hourglass_top</span>
          </div>
          <p className="text-slate-900 dark:text-white text-3xl font-bold mt-2">5</p>
           <p className="text-xs text-amber-600 dark:text-amber-400 font-medium mt-1">Requer atenção da diretoria</p>
        </div>
        <div className="flex flex-col gap-1 rounded-xl p-5 bg-white dark:bg-surface-dark border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="text-slate-500 dark:text-text-secondary text-sm font-medium">Negadas</p>
            <span className="material-symbols-outlined text-red-500 bg-red-500/10 p-1 rounded-md">cancel</span>
          </div>
          <p className="text-slate-900 dark:text-white text-3xl font-bold mt-2">1</p>
          <p className="text-xs text-slate-400 mt-1">Motivo: Falta de interstício</p>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2 px-1">
          <span className="material-symbols-outlined text-primary">today</span>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Permutas Ativas (Hoje)</h3>
        </div>
        <div className="bg-white dark:bg-surface-dark rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
             <table className="w-full text-left border-collapse">
               <thead className="bg-slate-50 dark:bg-[#1c1f27]">
                 <tr>
                   <th className="p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Horário</th>
                   <th className="p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Solicitante</th>
                   <th className="p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider hidden sm:table-cell">Substituto</th>
                   <th className="p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
                   <th className="p-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Ação</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                 <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                   <td className="p-4 text-sm font-medium text-slate-900 dark:text-white">07:00 - 19:00</td>
                   <td className="p-4">
                     <div className="flex items-center gap-3">
                       <img src="https://picsum.photos/32/32?random=8" className="rounded-full size-8 shrink-0" alt="Avatar"/>
                       <div className="flex flex-col">
                         <span className="text-sm font-semibold text-slate-900 dark:text-white">Of. Silva</span>
                         <span className="text-xs text-slate-500 dark:text-slate-400">Matrícula: 4821</span>
                       </div>
                     </div>
                   </td>
                   <td className="p-4 hidden sm:table-cell">
                     <div className="flex items-center gap-3">
                       <img src="https://picsum.photos/32/32?random=9" className="rounded-full size-8 shrink-0" alt="Avatar"/>
                       <div className="flex flex-col">
                         <span className="text-sm font-semibold text-slate-900 dark:text-white">Of. Santos</span>
                         <span className="text-xs text-slate-500 dark:text-slate-400">Matrícula: 3920</span>
                       </div>
                     </div>
                   </td>
                   <td className="p-4">
                     <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-500 border border-emerald-200 dark:border-emerald-500/20">
                        <span className="size-1.5 rounded-full bg-emerald-500"></span>
                        Aprovado
                     </span>
                   </td>
                   <td className="p-4 text-right">
                     <button className="text-sm text-slate-500 hover:text-primary font-medium">Detalhes</button>
                   </td>
                 </tr>
               </tbody>
             </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SwapList;
