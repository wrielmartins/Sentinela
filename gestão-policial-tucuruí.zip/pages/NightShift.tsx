import React from 'react';

const NightShift: React.FC = () => {
  return (
    <div className="flex flex-col h-full w-full bg-background-dark overflow-hidden">
      {/* Scrollable Container */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="w-full max-w-[1600px] mx-auto flex flex-col px-4 py-6 md:px-8 md:py-8 gap-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-slate-700 pb-6">
            <div className="flex flex-col gap-2">
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-white text-3xl md:text-4xl font-bold leading-tight">Plantão Charlie</h1>
                <span className="rounded bg-primary px-2 py-0.5 text-xs font-bold text-white uppercase tracking-wider whitespace-nowrap">Turno Ativo</span>
              </div>
              <p className="text-slate-400 text-sm md:text-base font-medium flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px]">calendar_today</span>
                14 de Outubro, 2023 
                <span className="mx-2 text-slate-600">|</span>
                <span className="text-emerald-400 font-mono font-bold tracking-wider">22:45:00</span>
              </p>
            </div>
            <div className="flex flex-wrap gap-3 w-full md:w-auto">
              <button className="flex-1 md:flex-none items-center justify-center gap-2 rounded-lg bg-slate-800 px-4 py-2 text-sm font-bold text-white hover:bg-slate-700 transition-colors border border-slate-700 whitespace-nowrap">
                <span className="material-symbols-outlined text-[18px]">history</span>
                Histórico
              </button>
              <button className="flex-1 md:flex-none items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-bold text-white hover:bg-blue-600 transition-colors shadow-lg shadow-blue-900/20 whitespace-nowrap">
                <span className="material-symbols-outlined text-[18px]">print</span>
                Gerar Relatório
              </button>
            </div>
          </div>

          {/* Cards Grid - Responsive */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1 rounded-xl bg-surface-dark border border-slate-700 p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-slate-400 text-sm font-bold uppercase tracking-wide">Efetivo Total</p>
                <span className="material-symbols-outlined text-slate-400">groups</span>
              </div>
              <p className="text-white text-3xl font-bold mt-2">12 Agentes</p>
              <div className="h-1.5 w-full bg-slate-800 rounded-full mt-3 overflow-hidden">
                <div className="h-full bg-emerald-500 w-full"></div>
              </div>
            </div>

            <div className="flex flex-col gap-1 rounded-xl bg-surface-dark border border-slate-700 p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-slate-400 text-sm font-bold uppercase tracking-wide">Armamento Letal</p>
                <span className="material-symbols-outlined text-slate-400">swords</span>
              </div>
              <div className="flex items-baseline gap-2 mt-2">
                <p className="text-white text-3xl font-bold">8</p>
                <span className="text-sm font-medium text-rose-400 bg-rose-400/10 px-1.5 py-0.5 rounded border border-rose-400/20 whitespace-nowrap">Fuzis 5.56</span>
              </div>
              <p className="text-slate-400 text-xs font-medium mt-1">+ 4 Espingardas Cal.12</p>
            </div>

            <div className="flex flex-col gap-1 rounded-xl bg-surface-dark border border-slate-700 p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-slate-400 text-sm font-bold uppercase tracking-wide">Postos Ativos</p>
                <span className="material-symbols-outlined text-slate-400">gite</span>
              </div>
              <p className="text-white text-3xl font-bold mt-2">100%</p>
              <p className="text-emerald-400 text-xs font-medium mt-1">Perímetro Seguro</p>
            </div>

            <div className="flex flex-col gap-1 rounded-xl bg-surface-dark border border-slate-700 p-5 shadow-sm relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent pointer-events-none"></div>
              <div className="flex items-center justify-between relative z-10">
                <p className="text-primary text-sm font-bold uppercase tracking-wide">Rodízio Atual</p>
                <span className="material-symbols-outlined text-primary">schedule</span>
              </div>
              <p className="text-white text-3xl font-bold mt-2 relative z-10">22h - 00h</p>
              <p className="text-slate-400 text-xs font-medium mt-1 relative z-10">Próxima Troca: 00:00</p>
            </div>
          </div>

          {/* Table Section */}
          <div className="flex flex-col gap-4 min-w-0">
             <h3 className="text-white text-xl font-bold px-1 flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">table_view</span>
              Quadro de Rotação Operacional
            </h3>
            <div className="w-full overflow-hidden rounded-xl border border-slate-700 bg-surface-dark shadow-xl">
               <div className="overflow-x-auto custom-scrollbar">
                 <table className="w-full min-w-[1000px] border-collapse">
                   <thead>
                     <tr className="bg-surface-darker border-b border-slate-700">
                       <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400 w-1/4">Posto / Local</th>
                       <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400 w-1/4 bg-slate-800/30">
                         Turno A <br/><span className="text-[10px] text-slate-500 font-normal normal-case block pt-1">(18h-20h / 00h-02h / 06h-08h)</span>
                       </th>
                       <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400 w-1/4">
                         Turno B <br/><span className="text-[10px] text-slate-500 font-normal normal-case block pt-1">(20h-22h / 02h-04h)</span>
                       </th>
                       <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-primary w-1/4 bg-primary/5 border-b-2 border-primary">
                         Turno C (Atual) <br/><span className="text-[10px] text-primary/80 font-normal normal-case block pt-1">(22h-00h / 04h-06h)</span>
                       </th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-800">
                      <tr className="bg-slate-900/50">
                        <td className="px-6 py-2 text-xs font-bold uppercase tracking-wider text-slate-500" colSpan={4}>Perímetro de Segurança</td>
                      </tr>
                      {/* Row 1 */}
                      <tr className="group hover:bg-slate-800/50 transition-colors">
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-3">
                             <div className="flex shrink-0 h-10 w-10 items-center justify-center rounded bg-slate-800 text-white font-bold border border-slate-700">G1</div>
                             <div className="min-w-0">
                               <p className="text-sm font-bold text-white truncate">Guarita Principal</p>
                               <p className="text-xs text-slate-500 truncate">Visão Frontal / Acesso</p>
                             </div>
                           </div>
                        </td>
                        <td className="px-4 py-3 bg-slate-800/30">
                          <div className="flex flex-col gap-1 p-2 rounded border border-transparent hover:border-slate-600 bg-slate-800/40">
                            <span className="text-sm font-medium text-slate-300">Of. Silva</span>
                            <span className="text-[10px] text-slate-500">Descanso</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                           <div className="flex flex-col gap-1 p-2 rounded border border-transparent hover:border-slate-600 bg-slate-800/40">
                            <span className="text-sm font-medium text-slate-300">Of. Souza</span>
                            <span className="text-[10px] text-slate-500">Descanso</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 bg-primary/5">
                          <div className="flex flex-col gap-1 p-3 rounded-lg border border-primary/30 bg-primary/10 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-2 h-2 bg-emerald-500 rounded-bl"></div>
                            <span className="text-sm font-bold text-white">Of. Mendes</span>
                            <span className="inline-flex w-fit items-center rounded bg-rose-500/20 px-1.5 py-0.5 text-[10px] font-medium text-rose-200 border border-rose-500/30 whitespace-nowrap">Fuzil 04</span>
                          </div>
                        </td>
                      </tr>
                      {/* Row 2 */}
                      <tr className="group hover:bg-slate-800/50 transition-colors">
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-3">
                             <div className="flex shrink-0 h-10 w-10 items-center justify-center rounded bg-slate-800 text-white font-bold border border-slate-700">G2</div>
                             <div className="min-w-0">
                               <p className="text-sm font-bold text-white truncate">Guarita Lateral Norte</p>
                               <p className="text-xs text-slate-500 truncate">Muralha Esquerda</p>
                             </div>
                           </div>
                        </td>
                        <td className="px-4 py-3 bg-slate-800/30">
                           <div className="flex flex-col gap-1 p-3 rounded-lg border border-primary/30 bg-primary/10 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-2 h-2 bg-emerald-500 rounded-bl"></div>
                            <span className="text-sm font-bold text-white">Of. Oliveira</span>
                            <span className="inline-flex w-fit items-center rounded bg-rose-500/20 px-1.5 py-0.5 text-[10px] font-medium text-rose-200 border border-rose-500/30 whitespace-nowrap">Fuzil 06</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                           <div className="flex flex-col gap-1 p-2 rounded border border-transparent hover:border-slate-600 bg-slate-800/40">
                            <span className="text-sm font-medium text-slate-300">Of. Costa</span>
                            <span className="text-[10px] text-slate-500">Descanso</span>
                          </div>
                        </td>
                         <td className="px-4 py-3 bg-primary/5">
                           <div className="flex flex-col gap-1 p-2 rounded border border-transparent hover:border-slate-600 bg-slate-800/40 opacity-50">
                            <span className="text-sm font-medium text-slate-300">Of. Oliveira</span>
                            <span className="text-[10px] text-slate-500">Posto Anterior</span>
                          </div>
                        </td>
                      </tr>
                   </tbody>
                 </table>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NightShift;