import React, { useState } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import DayShift from './pages/DayShift';
import NightShift from './pages/NightShift';
import SwapList from './pages/SwapList';
import SwapRequest from './pages/SwapRequest';
import Reports from './pages/Reports';
import Profile from './pages/Profile';
import Login from './pages/Login';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <HashRouter>
      <div className="flex h-screen w-screen overflow-hidden bg-background-light dark:bg-background-dark text-slate-900 dark:text-white">
        <Sidebar onLogout={handleLogout} />
        <main className="flex-1 flex flex-col h-full overflow-hidden relative">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/day-shift" element={<DayShift />} />
            <Route path="/night-shift" element={<NightShift />} />
            <Route path="/swaps" element={<SwapList />} />
            <Route path="/request-swap" element={<SwapRequest />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
